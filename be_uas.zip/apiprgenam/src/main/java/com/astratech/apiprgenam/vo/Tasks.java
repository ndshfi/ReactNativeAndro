package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "tasks")
public class Tasks {

 @Id
 @Column(name = "id")
 private Integer id;

 @Column(name = "task")
 private String task;

 @Column(name = "date")
 private String date;

 @Column(name = "status")
 private String status;

 public Tasks() {

 }

 public Tasks(Integer id, String task, String date, String status) {
 this.id = id;
 this.task = task;
 this.date = date;
 this.status = status;
 }

 public Integer getId() {
 return id;
 }

 public void setId(Integer id) {
 this.id = id;
 }

 public String getTask() {
 return task;
 }

 public void setTask(String task) {
 this.task = task;
 }

 public String getDate() {
 return date;
 }

 public void setDate(String date) {
 this.date = date;
 }

 public String getStatus() {
 return status;
 }

 public void setStatus(String status) {
 this.status = status;
 }
}
