package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.SalariesJpaRepository;
import com.astratech.apiprgenam.vo.Salaries;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SalariesService {

 @Qualifier("SalariesJpaRepository")
 @Autowired
 SalariesJpaRepository mSalariesJpaRepository;

 public Optional<Salaries> getSalaries(Integer nomor) {
 Optional<Salaries> salaries = mSalariesJpaRepository.findById(nomor);
 return salaries;
 }

 public List<Salaries> getSalariess() {
 List<Salaries> salariesList = mSalariesJpaRepository.findAllByOrderByNomorAsc();
 return salariesList;
 }
 public boolean saveSalaries(Salaries salaries){
 Salaries result = mSalariesJpaRepository.save(salaries);
 boolean isSuccess = true;

 if (result == null){
  isSuccess = false;
 }
 System.out.println("Sukses = "+isSuccess);
 return isSuccess;
 }

 public boolean updateSalaries(Salaries salaries){
 Optional<Salaries> result = mSalariesJpaRepository.findById(salaries.getNomor());

 if (result == null){
  System.out.println("ga ada di put nya");
  return false;
 }
 if(result.isPresent()){
  System.out.println("ada dong di put nya");
  System.out.println("id: "+salaries.getNomor());
  mSalariesJpaRepository.save(salaries);
 }
 return result.isPresent();
 }

 public boolean deleteSalaries(Integer nomor){
 Optional<Salaries> result = mSalariesJpaRepository.findById(nomor);
 if (result == null){
  return false;
 }
 if(result.isPresent()){
  mSalariesJpaRepository.delete(result.get());
 }
 return result.isPresent();
 }

}
