package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Task;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("TaskJpaRepository")
public interface TaskJpaRepository extends JpaRepository<Task, Integer> {
 public List<Task> findAllByOrderByIdAsc();
}