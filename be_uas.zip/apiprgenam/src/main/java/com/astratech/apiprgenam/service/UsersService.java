package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.UsersJpaRepository;
import com.astratech.apiprgenam.vo.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UsersService {

 @Qualifier("UsersJpaRepository")
 @Autowired
 UsersJpaRepository mUsersJpaRepository;

 public Optional<Users> getUsers(String username) {
 Optional<Users> users = mUsersJpaRepository.findById(username);
 return users;
 }



}
