package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Salaries;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository("SalariesJpaRepository")
public interface SalariesJpaRepository extends JpaRepository<Salaries, Integer> {
 public List<Salaries> findAllByOrderByNomorAsc();
}