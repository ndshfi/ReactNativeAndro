package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.TaskJpaRepository;
import com.astratech.apiprgenam.vo.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

 @Qualifier("TaskJpaRepository")
 @Autowired
 TaskJpaRepository mTaskJpaRepository;

 public Optional<Task> getTask(Integer id) {
 Optional<Task> task = mTaskJpaRepository.findById(id);
 return task;
 }

 public List<Task> getTasks() {
 List<Task> taskList = mTaskJpaRepository.findAllByOrderByIdAsc();
 return taskList;
 }

 public boolean saveTask(Task task){
 Task result = mTaskJpaRepository.save(task);
 boolean isSuccess = true;

 if (result == null){
  isSuccess = false;
 }
 System.out.println("Sukses = "+isSuccess);
 return isSuccess;
 }

 public boolean updateTask(Task task){
 Optional<Task> result = mTaskJpaRepository.findById(task.getId());

 if (result == null){
  System.out.println("ga ada di put nya");
  return false;
 }
 if(result.isPresent()){
  System.out.println("ada dong di put nya");
  System.out.println("id: "+task.getId());
  mTaskJpaRepository.save(task);
 }
 return result.isPresent();
 }

 public boolean deleteTask(Integer id){
 Optional<Task> result = mTaskJpaRepository.findById(id);
 if (result == null){
  return false;
 }
 if(result.isPresent()){
  mTaskJpaRepository.delete(result.get());
 }
 return result.isPresent();
 }

}
