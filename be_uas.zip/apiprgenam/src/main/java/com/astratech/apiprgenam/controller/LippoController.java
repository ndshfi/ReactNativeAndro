package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.LippoService;
import com.astratech.apiprgenam.vo.Result;
import com.astratech.apiprgenam.vo.Lippo;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
public class LippoController {

 @Autowired
 private LippoService lippoService;

 @GetMapping("/Lippo/{id}")
 public Lippo getLippo(@PathVariable Integer id) {
 System.out.println(id);
 Optional<Lippo> lippo = lippoService.getLippo(id);
 if (lippo.isPresent()) {
  System.out.println("ada");
  return lippo.get();
 } else {
  System.out.println("ga");
  return null;
 }
 }

 @GetMapping("/Lippos")
 public List<Lippo> getLippos() {
 return lippoService.getLippos();
 }

 @PostMapping("/Lippo")
 public Object saveLippo(HttpServletResponse response, @RequestBody Lippo param) {
 boolean isSuccess = lippoService.saveLippo(param);
 if (isSuccess) {
  return new Result(200, "Succes");
 }else {
  response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
  return new Result(500, "Failed to add task");
 }
 }

 @PutMapping("/Lippo")
 public Result updateLippo(@RequestBody Lippo lippo) {
 System.out.println("ini jalan put nya");
 boolean success = lippoService.updateLippo(lippo);
 if (success) {
  return new Result(1, "Lippo updated successfully");
 } else {
  return new Result(0, "Lippo not found or update failed");
 }
 }

 @DeleteMapping("/Lippo/{id}")
 public Result deleteLippo(@PathVariable Integer id) {
 boolean success = lippoService.deleteLippo(id);
 if (success) {
  return new Result(1, "Lippo deleted successfully");
 } else {
  return new Result(0, "Lippo not found or delete failed");
 }
 }
}