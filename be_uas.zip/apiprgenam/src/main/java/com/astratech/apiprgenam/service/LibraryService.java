package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.LibraryJpaRepository;
import com.astratech.apiprgenam.vo.Library;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LibraryService {

 @Qualifier("LibraryJpaRepository")
 @Autowired
 LibraryJpaRepository mLibraryJpaRepository;

 public Optional<Library> getLibrary(String ISSN) {
 Optional<Library> library = mLibraryJpaRepository.findById(ISSN);
 return library;
 }

 public List<Library> getLibrarys() {
 List<Library> libraryList = mLibraryJpaRepository.findAllByOrderByISSNAsc();
 return libraryList;
 }

 public Map<String, Long> countLibraryByGenres() {
 List<String> genres = Arrays.asList("Fantasy", "Sci-Fi", "Action");
 List<Object[]> results = mLibraryJpaRepository.countByGenres(genres);

 Map<String, Long> genreCountMap = new HashMap<>();
 for (Object[] row : results) {
  String genre = (String) row[0];
  Long count = (Long) row[1];
  genreCountMap.put(genre, count);
 }

 for (String genre : genres) {
  genreCountMap.putIfAbsent(genre, 0L);
 }

 return genreCountMap;
 }



 public boolean saveLibrary(Library library){
 Library result = mLibraryJpaRepository.save(library);
 boolean isSuccess = true;

 if (result == null){
  isSuccess = false;
 }
 System.out.println("Sukses = "+isSuccess);
 return isSuccess;
 }

 public boolean updateLibrary(Library library){
 Optional<Library> result = mLibraryJpaRepository.findById(library.getISSN());

 if (result == null){
  System.out.println("ga ada di put nya");
  return false;
 }
 if(result.isPresent()){
  System.out.println("ada dong di put nya");
  System.out.println("id: "+library.getISSN());
  mLibraryJpaRepository.save(library);
 }
 return result.isPresent();
 }

 public boolean deleteLibrary(String ISSN){
 Optional<Library> result = mLibraryJpaRepository.findById(ISSN);
 if (result == null){
  return false;
 }
 if(result.isPresent()){
  mLibraryJpaRepository.delete(result.get());
 }
 return result.isPresent();
 }

}
