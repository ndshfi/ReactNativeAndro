package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "task")
public class Task {

 @Id
 @Column(name = "id_task")
 private Integer id;

 @Column(name = "task_name")
 private String name;

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "task_date")
 private Date mDate;

 @Column(name = "task_status")
 private boolean status;

 public Task() {

 }

 public Task(Integer id, String name, Date mDate, boolean status) {
 this.id = id;
 this.name = name;
 this.mDate = mDate;
 this.status = status;
 }

 public Integer getId() {
 return id;
 }

 public void setId(Integer id) {
 this.id = id;
 }

 public String getName() {
 return name;
 }

 public void setName(String name) {
 this.name = name;
 }

 public Date getmDate() {
 return mDate;
 }

 public void setmDate(Date mDate) {
 this.mDate = mDate;
 }

 public boolean isStatus() {
 return status;
 }

 public void setStatus(boolean status) {
 this.status = status;
 }
}
