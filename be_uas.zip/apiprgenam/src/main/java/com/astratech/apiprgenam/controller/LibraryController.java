package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.LibraryService;
import com.astratech.apiprgenam.vo.Result;
import com.astratech.apiprgenam.vo.Library;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
public class LibraryController {

 @Autowired
 private LibraryService libraryService;

 @GetMapping("/Library/{id}")
 public Library getLibrary(@PathVariable String ISSN) {
 System.out.println(ISSN);
 Optional<Library> library = libraryService.getLibrary(ISSN);
 if (library.isPresent()) {
  System.out.println("ada");
  return library.get();
 } else {
  System.out.println("ga");
  return null;
 }
 }

 @GetMapping("/Librarys")
 public List<Library> getLibrarys() {
 return libraryService.getLibrarys();
 }

 @PostMapping("/Library")
 public Result saveLibrary(@RequestBody Library library) {
 System.out.println("iniid: "+library.getISSN());
 boolean success = libraryService.saveLibrary(library);
 if (success) {
  return new Result(1, "Library saved successfully");
 } else {
  return new Result(0, "Failed to save library");
 }
 }

 @GetMapping("/GenreCount")
 public Map<String, Long> countLibraryByGenre() {
 return libraryService.countLibraryByGenres();
 }

 @PutMapping("/Library")
 public Result updateLibrary(@RequestBody Library library) {
 System.out.println("ini jalan put nya");
 boolean success = libraryService.updateLibrary(library);
 if (success) {
  return new Result(1, "Library updated successfully");
 } else {
  return new Result(0, "Library not found or update failed");
 }
 }

 @DeleteMapping("/Library/{id}")
 public Result deleteLibrary(@PathVariable String ISSN) {
 boolean success = libraryService.deleteLibrary(ISSN);
 if (success) {
  return new Result(1, "Library deleted successfully");
 } else {
  return new Result(0, "Library not found or delete failed");
 }
 }
}