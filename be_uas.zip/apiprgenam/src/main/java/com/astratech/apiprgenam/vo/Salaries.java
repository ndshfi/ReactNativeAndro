package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

@Entity
@Table(name = "salaries")
public class Salaries {

// @GeneratedValue
 @Id
 @Column(name = "nomor")
 private Integer nomor;

 @Column(name = "date")
 private String date;


 @Column(name = "name_employee")
 private String name_employee;

 @Column(name = "working_days")
 private Integer working_days;

 @Column(name = "overtime_days")
 private Integer overtime_days;

 @Column(name = "position")
 private String position;

 @Column(name = "total_salary")
 private Integer total_salary;




 public Salaries() {

 }

 public Salaries(Integer nomor, String date, String name_employee, Integer working_days, Integer overtime_days, String position, Integer total_salary) {
 this.nomor = nomor;
 this.date = date;
 this.name_employee = name_employee;
 this.working_days = working_days;
 this.overtime_days = overtime_days;
 this.position = position;
 this.total_salary = total_salary;
 }

 public Integer getNomor() {
 return nomor;
 }

 public void setNomor(Integer nomor) {
 this.nomor = nomor;
 }

 public String getDate() {
 return date;
 }

 public void setDate(String date) {
 this.date = date;
 }

 public String getName_employee() {
 return name_employee;
 }

 public void setName_employee(String name_employee) {
 this.name_employee = name_employee;
 }

 public Integer getWorking_days() {
 return working_days;
 }

 public void setWorking_days(Integer working_days) {
 this.working_days = working_days;
 }

 public Integer getOvertime_days() {
 return overtime_days;
 }

 public void setOvertime_days(Integer overtime_days) {
 this.overtime_days = overtime_days;
 }

 public String getPosition() {
 return position;
 }

 public void setPosition(String position) {
 this.position = position;
 }

 public Integer getTotal_salary() {
 return total_salary;
 }

 public void setTotal_salary(Integer total_salary) {
 this.total_salary = total_salary;
 }
}

