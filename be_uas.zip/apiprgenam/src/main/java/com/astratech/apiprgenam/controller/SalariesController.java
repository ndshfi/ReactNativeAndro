package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.SalariesService;
import com.astratech.apiprgenam.vo.Salaries;
import com.astratech.apiprgenam.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
public class SalariesController {

 @Autowired
 private SalariesService salariesService;

 @GetMapping("/Salaries/{nomor}")
 public Salaries getSalaries(@PathVariable Integer nomor) {
 System.out.println(nomor.toString());
 Optional<Salaries> salaries = salariesService.getSalaries(nomor);
 if (salaries.isPresent()) {
  System.out.println("ada");
  return salaries.get();
 } else {
  System.out.println("ga");
  return null;
 }
 }

 @GetMapping("/Salariess")
 public List<Salaries> getSalariess() {
 return salariesService.getSalariess();
 }

 @PostMapping("/Salaries")
 public Result saveSalaries(@RequestBody Salaries salaries) {
 System.out.println("iniid: "+salaries.getNomor());
 boolean success = salariesService.saveSalaries(salaries);
 if (success) {
  return new Result(1, "Salaries saved successfully");
 } else {
  return new Result(0, "Failed to save salaries");
 }
 }

 @PutMapping("/Salaries")
 public Result updateSalaries(@RequestBody Salaries salaries) {
 System.out.println("ini jalan put nya");
 boolean success = salariesService.updateSalaries(salaries);
 if (success) {
  return new Result(1, "Salaries updated successfully");
 } else {
  return new Result(0, "Salaries not found or update failed");
 }
 }

 @DeleteMapping("/Salaries/{nomor}")
 public Result deleteSalaries(@PathVariable Integer nomor) {
 boolean success = salariesService.deleteSalaries(nomor);
 if (success) {
  return new Result(1, "Salaries deleted successfully");
 } else {
  return new Result(0, "Salaries not found or delete failed");
 }
 }
}