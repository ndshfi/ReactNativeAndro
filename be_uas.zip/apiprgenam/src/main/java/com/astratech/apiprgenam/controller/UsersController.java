package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.UsersService;
import com.astratech.apiprgenam.vo.Users;
import com.astratech.apiprgenam.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
public class UsersController {

 @Autowired
 private UsersService usersService;

 @GetMapping("/Users/{username}")
 public Users getUsers(@PathVariable String username) {
// public Users getUsers(@PathVariable String username, String password) {
 System.out.println(username+".");
 Optional<Users> users = usersService.getUsers(username);
// Optional<Users> passwords = usersService.getUsers(password);
// if (users.isPresent() && passwords.isPresent()) {
 if (users.isPresent() ) {
  System.out.println("ada");
  return users.get();
 } else {
  System.out.println("ga");
  return null;
 }
 }



}