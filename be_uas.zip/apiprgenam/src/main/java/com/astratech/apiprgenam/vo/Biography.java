package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "biography")
public class Biography {

 @Id
 @Column(name = "username")
 private String username;

 @Column(name = "password")
 private String password;

 @Column(name = "nama_user")
 private String nama_user;

 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "tanggal_lahir")
 private Date tanggal_lahir;

 @Column(name = "status")
 private String status;

 public Biography(String username, String password, String nama_user, Date tanggal_lahir, String status) {
 this.username = username;
 this.password = password;
 this.nama_user = nama_user;
 this.tanggal_lahir = tanggal_lahir;
 this.status = status;
 }

 public Biography() {

 }

 public String getUsername() {
 return username;
 }

 public void setUsername(String username) {
 this.username = username;
 }

 public String getPassword() {
 return password;
 }

 public void setPassword(String password) {
 this.password = password;
 }

 public String getNama_user() {
 return nama_user;
 }

 public void setNama_user(String nama_user) {
 this.nama_user = nama_user;
 }

 public Date getTanggal_lahir() {
 return tanggal_lahir;
 }

 public void setTanggal_lahir(Date tanggal_lahir) {
 this.tanggal_lahir = tanggal_lahir;
 }

 public String getStatus() {
 return status;
 }

 public void setStatus(String status) {
 this.status = status;
 }
}

