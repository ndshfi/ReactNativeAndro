package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "lippo")
public class Lippo {

 @Id
 @Column(name = "id_rumah")
 private Integer id;

 @Column(name = "nama_rumah")
 private String name;

 @Column(name = "jenis_rumah")
 private String jenis;

 @Column(name = "luas_tanah")
 private Integer tanah;

 @Column(name = "luas_bangunan")
 private Integer bangunan;

 @Column(name = "harga_rumah")
 private Double harga;


 public Lippo() {

 }

 public Lippo(Integer id, String name, String jenis, Integer tanah, Integer bangunan, Double harga) {
 this.id = id;
 this.name = name;
 this.jenis = jenis;
 this.tanah = tanah;
 this.bangunan = bangunan;
 this.harga = harga;
 }

 public Integer getId() {
 return id;
 }

 public void setId(Integer id) {
 this.id = id;
 }

 public String getName() {
 return name;
 }

 public void setName(String name) {
 this.name = name;
 }

 public String getJenis() {
 return jenis;
 }

 public void setJenis(String jenis) {
 this.jenis = jenis;
 }

 public Integer getTanah() {
 return tanah;
 }

 public void setTanah(Integer tanah) {
 this.tanah = tanah;
 }

 public Integer getBangunan() {
 return bangunan;
 }

 public void setBangunan(Integer bangunan) {
 this.bangunan = bangunan;
 }

 public Double getHarga() {
 return harga;
 }

 public void setHarga(Double harga) {
 this.harga = harga;
 }
}
