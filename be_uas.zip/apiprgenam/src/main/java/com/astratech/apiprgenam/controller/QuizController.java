package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.QuizService;
import com.astratech.apiprgenam.vo.Quiz;
import com.astratech.apiprgenam.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
public class QuizController {

 @Autowired
 private QuizService quizService;

 @GetMapping("/Quiz/{id}")
 public Quiz getQuiz(@PathVariable Integer id) {
 System.out.println(id);
 Optional<Quiz> quiz = quizService.getQuiz(id);
 if (quiz.isPresent()) {
  System.out.println("ada");
  return quiz.get();
 } else {
  System.out.println("ga");
  return null;
 }
 }

 @GetMapping("/Quizs")
 public List<Quiz> getQuizs() {
 return quizService.getQuizs();
 }

 @PostMapping("/Quiz")
 public Result saveQuiz(@RequestBody Quiz quiz) {
 System.out.println("iniid: "+quiz.getId());
 boolean success = quizService.saveQuiz(quiz);
 if (success) {
  return new Result(1, "Quiz saved successfully");
 } else {
  return new Result(0, "Failed to save quiz");
 }
 }

 @PutMapping("/Quiz")
 public Result updateQuiz(@RequestBody Quiz quiz) {
 System.out.println("ini jalan put nya");
 boolean success = quizService.updateQuiz(quiz);
 if (success) {
  return new Result(1, "Quiz updated successfully");
 } else {
  return new Result(0, "Quiz not found or update failed");
 }
 }

 @DeleteMapping("/Quiz/{id}")
 public Result deleteQuiz(@PathVariable Integer id) {
 boolean success = quizService.deleteQuiz(id);
 if (success) {
  return new Result(1, "Quiz deleted successfully");
 } else {
  return new Result(0, "Quiz not found or delete failed");
 }
 }
}