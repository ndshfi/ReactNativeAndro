package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "library")
public class Library {

 @Id
 @Column(name = "ISSN")
 private String ISSN;

 @Column(name = "judul")
 private String judul;

 @Column(name = "genre")
 private String genre;

 @Column(name = "penerbit")
 private String penerbit;



 @Temporal(TemporalType.TIMESTAMP)
 @Column(name = "tanggal_terbit")
 private Date tanggal_terbit;

// @Column(name = "task_status")
// private boolean status;

 public Library() {

 }

 public Library(String ISSN, String judul, String genre, String penerbit, Date tanggal_terbit) {
 this.ISSN = ISSN;
 this.judul = judul;
 this.genre = genre;
 this.penerbit = penerbit;
 this.tanggal_terbit = tanggal_terbit;
 }

 public String getISSN() {
 return ISSN;
 }

 public void setISSN(String ISSN) {
 this.ISSN = ISSN;
 }

 public String getJudul() {
 return judul;
 }

 public void setJudul(String judul) {
 this.judul = judul;
 }

 public Date getTanggal_terbit() {
 return tanggal_terbit;
 }

 public void setTanggal_terbit(Date tanggal_terbit) {
 this.tanggal_terbit = tanggal_terbit;
 }

 public String getGenre() {
 return genre;
 }

 public void setGenre(String genre) {
 this.genre = genre;
 }

 public String getPenerbit() {
 return penerbit;
 }

 public void setPenerbit(String penerbit) {
 this.penerbit = penerbit;
 }

// public boolean isStatus() {
// return status;
// }

// public void setStatus(boolean status) {
// this.status = status;
// }
}
