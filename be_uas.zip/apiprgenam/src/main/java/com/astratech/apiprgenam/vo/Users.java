package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "users")
public class Users {

 @Id
 @Column(name = "username")
 private String username;

 @Column(name = "password")
 private String password;



 public Users(String username, String password) {
 this.username = username;
 this.password = password;
 }

 public Users() {

 }

 public String getUsername() {
 return username;
 }

 public void setUsername(String username) {
 this.username = username;
 }

 public String getPassword() {
 return password;
 }

 public void setPassword(String password) {
 this.password = password;
 }

}

