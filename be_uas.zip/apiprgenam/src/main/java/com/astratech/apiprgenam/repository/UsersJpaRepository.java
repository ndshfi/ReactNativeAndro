package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("UsersJpaRepository")
public interface UsersJpaRepository extends JpaRepository<Users, String> {
 public List<Users> findAllByOrderByUsernameAsc();
//
// @Query("SELECT l.genre, COUNT(l) FROM Users l WHERE l.genre IN (:genres) GROUP BY l.genre")
// List<Object[]> countByGenres(@Param("genres") List<String> genres);


}