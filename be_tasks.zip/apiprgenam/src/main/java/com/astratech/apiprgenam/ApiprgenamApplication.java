package com.astratech.apiprgenam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiprgenamApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiprgenamApplication.class, args);
    }

}
