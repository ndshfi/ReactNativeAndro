package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Tasks;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("TasksJpaRepository")
public interface TasksJpaRepository extends JpaRepository<Tasks, Integer> {
    public List<Tasks> findAllByOrderByIdAsc();
}