package com.astratech.apiprgenam.vo;

import jakarta.persistence.*;

import java.util.Date;

@Entity
@Table(name = "quiz")
public class Quiz {

    @Id
    @Column(name = "id")
    private Integer id;

    @Column(name = "name")
    private String name;

    @Column(name = "answer")
    private String answer;

    @Column(name = "status")
    private String status;

    public Quiz(Integer id, String name, String answer, String status) {
        this.id = id;
        this.name = name;
        this.answer = answer;
        this.status = status;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAnswer() {
        return answer;
    }

    public void setAnswer(String answer) {
        this.answer = answer;
    }

    public Quiz() {

    }
public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}

