package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.TaskService;
import com.astratech.apiprgenam.vo.Result;
import com.astratech.apiprgenam.vo.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
public class TaskController {

    @Autowired
    private TaskService taskService;

    @GetMapping("/Task/{id}")
    public Task getTask(@PathVariable Integer id) {
        System.out.println(id);
        Optional<Task> task = taskService.getTask(id);
        if (task.isPresent()) {
            System.out.println("ada");
            return task.get();
        } else {
            System.out.println("ga");
            return null;
        }
    }

    @GetMapping("/Tasks")
    public List<Task> getTasks() {
        return taskService.getTasks();
    }

    @PostMapping("/Task")
    public Result saveTask(@RequestBody Task task) {
        System.out.println("iniid "+task.getId());
        boolean success = taskService.saveTask(task);
        if (success) {
            return new Result(1, "Task saved successfully");
        } else {
            return new Result(0, "Failed to save task");
        }
    }

    @PutMapping("/Task")
    public Result updateTask(@RequestBody Task task) {
        System.out.println("ini jalan put nya");
        boolean success = taskService.updateTask(task);
        if (success) {
            return new Result(1, "Task updated successfully");
        } else {
            return new Result(0, "Task not found or update failed");
        }
    }

    @DeleteMapping("/Task/{id}")
    public Result deleteTask(@PathVariable Integer id) {
        boolean success = taskService.deleteTask(id);
        if (success) {
            return new Result(1, "Task deleted successfully");
        } else {
            return new Result(0, "Task not found or delete failed");
        }
    }
}