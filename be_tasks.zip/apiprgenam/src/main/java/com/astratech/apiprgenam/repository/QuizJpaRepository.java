package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Quiz;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("QuizJpaRepository")
public interface QuizJpaRepository extends JpaRepository<Quiz, Integer> {
    public List<Quiz> findAllByOrderByIdAsc();


}