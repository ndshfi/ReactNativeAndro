package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.BiographyJpaRepository;
import com.astratech.apiprgenam.vo.Biography;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class BiographyService {

    @Qualifier("BiographyJpaRepository")
    @Autowired
    BiographyJpaRepository mBiographyJpaRepository;

    public Optional<Biography> getBiography(String username) {
        Optional<Biography> biography = mBiographyJpaRepository.findById(username);
        return biography;
    }

    public List<Biography> getBiographys() {
        List<Biography> biographyList = mBiographyJpaRepository.findAllByOrderByUsernameAsc();
        return biographyList;
    }
    public boolean saveBiography(Biography biography){
       Biography result = mBiographyJpaRepository.save(biography);
        boolean isSuccess = true;

        if (result == null){
            isSuccess = false;
        }
        System.out.println("Sukses = "+isSuccess);
        return isSuccess;
    }

    public boolean updateBiography(Biography biography){
        Optional<Biography> result = mBiographyJpaRepository.findById(biography.getUsername());

        if (result == null){
            System.out.println("ga ada di put nya");
            return false;
        }
        if(result.isPresent()){
            System.out.println("ada dong di put nya");
            System.out.println("id: "+biography.getUsername());
            mBiographyJpaRepository.save(biography);
        }
        return result.isPresent();
    }

    public boolean deleteBiography(String ISSN){
        Optional<Biography> result = mBiographyJpaRepository.findById(ISSN);
        if (result == null){
            return false;
        }
        if(result.isPresent()){
            mBiographyJpaRepository.delete(result.get());
        }
        return result.isPresent();
    }

}
