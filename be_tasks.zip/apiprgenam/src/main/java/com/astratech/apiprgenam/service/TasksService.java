package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.TasksJpaRepository;
import com.astratech.apiprgenam.vo.Tasks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TasksService {

    @Qualifier("TasksJpaRepository")
    @Autowired
    TasksJpaRepository mTasksJpaRepository;

    public Optional<Tasks> getTasks(Integer id) {
        Optional<Tasks> tasks = mTasksJpaRepository.findById(id);
        return tasks;
    }

    public List<Tasks> getTaskss() {
        List<Tasks> tasksList = mTasksJpaRepository.findAllByOrderByIdAsc();
        return tasksList;
    }

    public boolean saveTasks(Tasks tasks){
     Tasks result = mTasksJpaRepository.save(tasks);
        boolean isSuccess = true;

        if (result == null){
            isSuccess = false;
        }
        System.out.println("Sukses = "+isSuccess);
        return isSuccess;
    }

    public boolean updateTasks(Tasks tasks){
        Optional<Tasks> result = mTasksJpaRepository.findById(tasks.getId());

        if (result == null){
            System.out.println("ga ada di put nya");
            return false;
        }
        if(result.isPresent()){
            System.out.println("ada dong di put nya");
            System.out.println("id: "+tasks.getId());
            mTasksJpaRepository.save(tasks);
        }
        return result.isPresent();
    }

    public boolean deleteTasks(Integer id){
        Optional<Tasks> result = mTasksJpaRepository.findById(id);
        if (result == null){
            return false;
        }
        if(result.isPresent()){
            mTasksJpaRepository.delete(result.get());
        }
        return result.isPresent();
    }

}
