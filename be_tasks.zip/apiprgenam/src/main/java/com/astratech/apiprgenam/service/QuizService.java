package com.astratech.apiprgenam.service;

import com.astratech.apiprgenam.repository.QuizJpaRepository;
import com.astratech.apiprgenam.vo.Quiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class QuizService {

    @Qualifier("QuizJpaRepository")
    @Autowired
    QuizJpaRepository mQuizJpaRepository;

    public Optional<Quiz> getQuiz(Integer id) {
        Optional<Quiz> quiz = mQuizJpaRepository.findById(id);
        return quiz;
    }

    public List<Quiz> getQuizs() {
        List<Quiz> quizList = mQuizJpaRepository.findAllByOrderByIdAsc();
        return quizList;
    }
    public boolean saveQuiz(Quiz quiz){
       Quiz result = mQuizJpaRepository.save(quiz);
        boolean isSuccess = true;

        if (result == null){
            isSuccess = false;
        }
        System.out.println("Sukses = "+isSuccess);
        return isSuccess;
    }

    public boolean updateQuiz(Quiz quiz){
        Optional<Quiz> result = mQuizJpaRepository.findById(quiz.getId());

        if (result == null){
            System.out.println("ga ada di put nya");
            return false;
        }
        if(result.isPresent()){
            System.out.println("ada dong di put nya");
            System.out.println("id: "+quiz.getId());
            mQuizJpaRepository.save(quiz);
        }
        return result.isPresent();
    }

    public boolean deleteQuiz(Integer id){
        Optional<Quiz> result = mQuizJpaRepository.findById(id);
        if (result == null){
            return false;
        }
        if(result.isPresent()){
            mQuizJpaRepository.delete(result.get());
        }
        return result.isPresent();
    }

}
