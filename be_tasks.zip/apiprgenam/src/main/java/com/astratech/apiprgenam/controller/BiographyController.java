package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.BiographyService;
import com.astratech.apiprgenam.vo.Biography;
import com.astratech.apiprgenam.vo.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;


@RestController
public class BiographyController {

    @Autowired
    private BiographyService biographyService;

    @GetMapping("/Biography/{username}")
    public Biography getBiography(@PathVariable String username) {
        System.out.println(username);
        Optional<Biography> biography = biographyService.getBiography(username);
        if (biography.isPresent()) {
            System.out.println("ada");
            return biography.get();
        } else {
            System.out.println("ga");
            return null;
        }
    }

    @GetMapping("/Biographys")
    public List<Biography> getBiographys() {
        return biographyService.getBiographys();
    }

    @PostMapping("/Biography")
    public Result saveBiography(@RequestBody Biography biography) {
        System.out.println("iniid: "+biography.getUsername());
        boolean success = biographyService.saveBiography(biography);
        if (success) {
            return new Result(1, "Biography saved successfully");
        } else {
            return new Result(0, "Failed to save biography");
        }
    }

    @PutMapping("/Biography")
    public Result updateBiography(@RequestBody Biography biography) {
        System.out.println("ini jalan put nya");
        boolean success = biographyService.updateBiography(biography);
        if (success) {
            return new Result(1, "Biography updated successfully");
        } else {
            return new Result(0, "Biography not found or update failed");
        }
    }

    @DeleteMapping("/Biography/{username}")
    public Result deleteBiography(@PathVariable String username) {
        boolean success = biographyService.deleteBiography(username);
        if (success) {
            return new Result(1, "Biography deleted successfully");
        } else {
            return new Result(0, "Biography not found or delete failed");
        }
    }
}