package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Biography;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("BiographyJpaRepository")
public interface BiographyJpaRepository extends JpaRepository<Biography, String> {
    public List<Biography> findAllByOrderByUsernameAsc();
//
//    @Query("SELECT l.genre, COUNT(l) FROM Biography l WHERE l.genre IN (:genres) GROUP BY l.genre")
//    List<Object[]> countByGenres(@Param("genres") List<String> genres);


}