package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Library;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("LibraryJpaRepository")
public interface LibraryJpaRepository extends JpaRepository<Library, String> {
    public List<Library> findAllByOrderByISSNAsc();

    @Query("SELECT l.genre, COUNT(l) FROM Library l WHERE l.genre IN (:genres) GROUP BY l.genre")
    List<Object[]> countByGenres(@Param("genres") List<String> genres);


}