package com.astratech.apiprgenam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiprgenamApplicationTests {

    @Test
    void contextLoads() {
    }

}
