package com.astratech.apiprgenam.controller;

import com.astratech.apiprgenam.service.TasksService;
import com.astratech.apiprgenam.vo.Result;
import com.astratech.apiprgenam.vo.Tasks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;


@RestController
public class TasksController {

    @Autowired
    private TasksService tasksService;

    @GetMapping("/Taskss/{id}")
    public Tasks getTasks(@PathVariable Integer id) {
        System.out.println(id);
        Optional<Tasks> tasks = tasksService.getTasks(id);
        if (tasks.isPresent()) {
            System.out.println("ada");
            return tasks.get();
        } else {
            System.out.println("ga");
            return null;
        }
    }

    @GetMapping("/Taskss")
    public List<Tasks> getTaskss() {
        return tasksService.getTaskss();
    }

    @PostMapping("/Tasks")
    public Result saveTasks(@RequestBody Tasks tasks) {
        System.out.println("iniid "+tasks.getId());
        boolean success = tasksService.saveTasks(tasks);
        if (success) {
            return new Result(1, "Tasks saved successfully");
        } else {
            return new Result(0, "Failed to save tasks");
        }
    }

    @PutMapping("/Tasks")
    public Result updateTasks(@RequestBody Tasks tasks) {
        System.out.println("ini jalan put nya");
        boolean success = tasksService.updateTasks(tasks);
        if (success) {
            return new Result(1, "Tasks updated successfully");
        } else {
            return new Result(0, "Tasks not found or update failed");
        }
    }

    @DeleteMapping("/Tasks/{id}")
    public Result deleteTasks(@PathVariable Integer id) {
        boolean success = tasksService.deleteTasks(id);
        if (success) {
            return new Result(1, "Tasks deleted successfully");
        } else {
            return new Result(0, "Tasks not found or delete failed");
        }
    }
}