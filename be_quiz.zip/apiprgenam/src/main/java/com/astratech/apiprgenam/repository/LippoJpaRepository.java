package com.astratech.apiprgenam.repository;

import com.astratech.apiprgenam.vo.Lippo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository("LippoJpaRepository")
public interface LippoJpaRepository extends JpaRepository<Lippo, Integer> {
    public List<Lippo> findAllByOrderByIdAsc();
}